SKILL := /Users/peiziye/Desktop/国际物理竞赛/uphysicsc-paper-toolkit/skill/upc-paper
